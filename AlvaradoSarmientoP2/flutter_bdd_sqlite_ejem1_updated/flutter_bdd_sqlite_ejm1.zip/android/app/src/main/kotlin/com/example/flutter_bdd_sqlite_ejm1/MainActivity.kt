package com.example.flutter_bdd_sqlite_ejm1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
