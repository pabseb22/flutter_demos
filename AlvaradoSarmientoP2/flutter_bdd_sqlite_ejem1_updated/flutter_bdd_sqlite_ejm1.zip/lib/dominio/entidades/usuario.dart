//clase usuario
class Usuario {
  //atributos
  final int id;
  final String nombre;
  final String email;
  //constructor
  Usuario({required this.id, required this.nombre, required this.email});
}
