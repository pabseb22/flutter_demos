
import 'package:flutter/material.dart';
import 'package:flutter_bdd_sqlite_ejm1/data/modelo/usuario_modelo.dart';
import 'package:flutter_bdd_sqlite_ejm1/dominio/repositorio/usuario_repositorio.dart';

class PaginaPrincipal extends StatefulWidget {
  const PaginaPrincipal({super.key});

  @override
  State<PaginaPrincipal> createState() => _PaginaPrincipalState();
}

class _PaginaPrincipalState extends State<PaginaPrincipal> {
    // Instancia del repositorio para manejar la base de datos
  final UsuarioRepositorio usuarioRepositorio = UsuarioRepositorio();
    // Lista para almacenar los usuarios recuperados de la base de datos
  List<UsuarioModel> usuarios = [];

  // Controladores para capturar el texto de los TextFields
  final TextEditingController nombreController = TextEditingController();
  final TextEditingController emailController = TextEditingController();

// initState se ejecuta una vez cuando la página se inicializa
  @override
  void initState() {
    super.initState();
    _cargarUsuarios();
  }
// Método para cargar usuarios desde la base de datos
  Future<void> _cargarUsuarios() async {
    final data = await usuarioRepositorio.obtenerUsuarios();
    setState(() {
      usuarios = data; // Actualiza la lista de usuarios
    });
  }
// Método para agregar un nuevo usuario
  Future<void> _agregarUsuario() async {
      // Validar que los campos no estén vacíos
    if (nombreController.text.isEmpty || emailController.text.isEmpty) return;
  // Crear un nuevo usuario con los datos ingresados
    final nuevoUsuario = UsuarioModel(
      //// id=0 indica que SQLite debe generar el ID
      id: 0,  // id = 0 para que SQLite lo autogenere (AUTOINCREMENT), si se coloca otro numero no se puede colocar mas usuarios
      nombre: nombreController.text,
      email: emailController.text,
    );
// Insertar el nuevo usuario en la base de datos
    await usuarioRepositorio.insertarUsuario(nuevoUsuario);
     // Limpiar los campos después de agregar
    nombreController.clear();
    emailController.clear();
    _cargarUsuarios();
  }
  //---  Colocar aqui el método de Eliminar -------------------------
  // Método para eliminar un usuario por id


//--------------------------------------------------------------------

  // Método para editar un usuario
  Future<void> _editarUsuario(UsuarioModel usuario) async {
    nombreController.text = usuario.nombre;
    emailController.text = usuario.email;

    // Mostrar un Dialog para editar los datos del usuario
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Editar Usuario'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nombreController,
                decoration: const InputDecoration(labelText: 'Nombre'),
              ),
              TextField(
                controller: emailController,
                decoration: const InputDecoration(labelText: 'Email'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                final usuarioEditado = UsuarioModel(
                  id: usuario.id,
                  nombre: nombreController.text,
                  email: emailController.text,
                );
                await usuarioRepositorio.actualizarUsuario(usuarioEditado);
                // ignore: use_build_context_synchronously
                Navigator.pop(context);
                _cargarUsuarios(); // Actualizar lista de usuarios
              },
              child: const Text('Guardar Cambios'),
            ),
          ],
        );
      },
    );
  }
//-----------------------------------------------------------------------
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Usuarios - SQlite')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: nombreController,
              decoration: const InputDecoration(labelText: 'Nombre'),
            ),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _agregarUsuario,
              child: const Text('Agregar Usuario'),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: usuarios.length,
                itemBuilder: (context, index) {
                  final usuario = usuarios[index];
                  return Card(
                    child: ListTile(
                      title: Text(usuario.nombre),
                      subtitle: Text(usuario.email),
                      trailing: 
                               IconButton(
                            icon: const Icon(Icons.edit, color: Colors.blue),
                            onPressed: () => _editarUsuario(usuario),
                          ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
