import 'package:flutter/material.dart';
import 'package:flutter_bdd_sqlite_ejm1/presentacion/pagina_principal.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'BDD - SQLite',
      home: PaginaPrincipal(),
    );
  }
}




// flutter_sqlite
// ├── lib/
// │   ├── data/
// │   │   ├── db/
// │   │   │   └── data_base.dart
// │   │   └── models/
// │   │       └── usuario_modeol.dart
// │   ├── domain/
// │   │   ├── entidades/
// │   │   │   └── usuario.dart
// │   │   └── repositorio/
// │   │       └── usuario_repositorio.dart
// │   ├── presentation/
// │   │   └── pagina_principal.dart
// │   ├── main.dart
// └── pubspec.yaml
